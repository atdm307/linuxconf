#!/bin/bash
# масове редагування; користуйтеся обережно!

for i in `find $HOME/man/uk -type f -name "*.[1-8]"`; do
    bi=`basename $i`
    sed -e 's/^\(\.SH\) ЗВЕДЕННЯ\s*$/\1 ВИКОРИСТАННЯ/'
      # -e 's/^\.B \([a-z_0-9-]\{,30\}\)()/.BR \1 ()/'
      # -e 's/^\.BR \([a-z_0-9-]\{,30\}\)() \([,.]\)/.BR \1 ()\2/'
        -e 's/^\(\.SH\) ПОРТАБЕЛЬНІСТЬ/\1 ПЕРЕНОСИМІСТЬ/' $i > /tmp/$bi
    mv /tmp/$bi $i
    echo -n "$bi "
done

echo


# $Id: maned.sh 4 2011-03-12 00:34:43Z fauve $
