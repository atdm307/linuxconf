#!/bin/bash 

mandir=$HOME/man

if [[ $UK_MANDIR ]]; then
    mandir=$UK_MANDIR
fi

todo=$mandir/data/TODO-GLIBC
ref=$mandir/data/ALL-GLIBC

echo > $todo-2  # TODO-GLIBC-2
echo > $todo-3  # TODO-GLIBC-3

for i in `cat $ref`; do
    section='?'
    if [[ -a $mandir/uk/man3/$i.3 ]]; then
	echo $i.3 +
	#section=3
	#uwhatis $i | grep "($section)" | uniq  >> $todo
    elif [[ -a $mandir/uk/man2/$i.2 ]]; then
	echo $i.2 +
	#section=2
	#uwhatis $i | grep "($section)" | uniq >> $todo
    else
	lines=`man 3 $i 2>/dev/null | wc -l | sed 's/[\t ]*//g'`
	section=3
	if [[ $lines -eq 0 ]]; then 
	    lines=`man 2 $i 2>/dev/null | wc -l | sed 's/[\t ]*//g'`
	    section=2
	fi
	if [[ $lines -eq 0 ]]; then
	    continue
	else
	    echo $i -
	    echo -ne "$i\t" >> $todo-$section
	    echo -n "($section) [$lines]" >> $todo-$section
            descr=`whatis $i | grep "([23])" | sed "s/^.* - / - /" | uniq`
	    if [[ $descr = "" ]]; then
		echo >> $todo-$section
	    else
		echo "$descr" >> $todo-$section
	    fi
       fi
    fi
done
