allf=$HOME/man/data/ALL-3
todof=$HOME/man/data/TODO-3
whatisf=$HOME/man/data/WHATIS-3

echo -n > $todof

# for i in `sed 's/^\([^ \t]\+\).*/\1/' $whatisf`; do
for i in `cat $allf`; do
    if [[ -e "$HOME/man/uk/man3/$i.3" ]]; then
	echo "$i.3 exists"
    else
	echo -ne "$i.3\t" >> $todof
	lines=`man 3 $i | wc -l | sed 's/[\t ]*//g'`
	echo -n "[$lines]" >> $todof
	grep "^$i " $whatisf | sed 's/^.* - / - /' | uniq >> $todof
    fi
done
